export interface Country {
    id: number;
    sortname: string;
    name: string;
    phoneCode: number;
}