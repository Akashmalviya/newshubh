export interface Hero
{
    'status': Number;


    'data': [
        {
            'itemName': Number,
           'deletedAt': Number,
            '_id': String,
            'createdAt': Date,
            'updatedAt':Date,
            '__v': Number
        },
    ],
    'message' : String;
}

