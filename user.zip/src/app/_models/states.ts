export interface State {
    id: string;
    name: string;
    country_id: string;
}
