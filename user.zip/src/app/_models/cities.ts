export interface cities {
    id: string;
    name: string;
    state_id: string;
}
