import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trip-support',
  templateUrl: './trip-support.component.html',
  styleUrls: ['./trip-support.component.scss']
})
export class TripSupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
