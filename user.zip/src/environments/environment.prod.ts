export const environment = {
  production: true,
  API_URL : 'https://reqres.in/api/',
  // baseUrl : 'http://18.224.140.86:3000/'      //QA
  baseUrl : 'http://18.189.17.129:3000/'   //UAT

};
